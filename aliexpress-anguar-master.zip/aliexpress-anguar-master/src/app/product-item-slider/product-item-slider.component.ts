import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-item-slider',
  templateUrl: './product-item-slider.component.html',
  styleUrls: ['./product-item-slider.component.css']
})
export class ProductItemSliderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
