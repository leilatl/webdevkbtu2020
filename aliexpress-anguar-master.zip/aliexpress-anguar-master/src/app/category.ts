export interface ICategory {
    id: number,
    path: string,
    name: string
}