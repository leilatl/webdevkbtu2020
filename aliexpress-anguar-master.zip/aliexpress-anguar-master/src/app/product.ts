export interface IProduct {
    id: number,
    category: string,
    name: string,
    image: string,
    descriprion: string,
    rating: string,
    link: string
}